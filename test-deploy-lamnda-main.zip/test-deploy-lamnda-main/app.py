
def handler(event, context):
    return 'PEPE'