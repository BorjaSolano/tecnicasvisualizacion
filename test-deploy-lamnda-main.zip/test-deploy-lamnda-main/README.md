# test-deploy-lamnda

HOLA

git config --global user.email "fernando.decalle@gmail.com"
git config --global user.name "Fernando"